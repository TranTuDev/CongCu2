import { MovieManagement } from "@/components/movie-management"

export default function MoviesPage() {
  return <MovieManagement />
}
