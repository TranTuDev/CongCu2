import { ShowtimeManagement } from "@/components/showtime-management"

export default function ShowtimesPage() {
  return <ShowtimeManagement />
}
