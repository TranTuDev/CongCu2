import { CustomerManagement } from "@/components/customer-management"

export default function Page() {
  return <CustomerManagement />
}
